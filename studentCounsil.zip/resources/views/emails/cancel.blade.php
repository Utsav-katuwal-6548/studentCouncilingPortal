Hi <strong>{{ $name }}</strong>,

<p>Appointment Has been canceled by Student</p>

<p>Student Name : {{ $body }}</p>

<p>Subject : {{$subject}}</p>

<p>Date : {{$date}}</p>

<p>Time : {{$time}}</p>

<p>Message : {{$msg}}</p>

<br>

<br>

Thankyou! 

<br>

Student Counseling
