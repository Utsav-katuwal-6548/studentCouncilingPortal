Hi <strong>{{ $name }}</strong>,

<p>Your Appointment request has been sent to the selected Teacher.</p>

<p>Teacher Name : {{ $body }}</p>

<p>Subject : {{$subject}}</p>

<p>Date : {{$date}}</p>

<p>Time : {{$time}}</p>

Thankyou!

Student Counseling
