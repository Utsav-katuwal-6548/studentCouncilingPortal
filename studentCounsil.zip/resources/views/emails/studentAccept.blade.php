Hi <strong>{{ $name }}</strong>,

<p>Your Appointment request has been approved.</p>

<p>Teacher Name : {{ $body }}</p>

<p>Subject : {{$subject}}</p>

<p>Date : {{$date}}</p>

<p>Time : {{$time}}</p>

<br>
Thankyou!

<br>

Student Counseling
