Hi <strong>{{ $name }}</strong>,

<p>Your Appointment request has been rejected.</p>

<p>Teacher Name : {{ $body }}</p>

<p>Subject : {{$subject}}</p>

<p>Date : {{$date}}</p>

<p>Time : {{$time}}</p>

<p>Message : {{$tchMessage}}</p>
<br>
Thankyou!

<br>

Student Counseling
