Hi <strong>{{ $name }}</strong>,

<p>You have new appointment Request</p>

<p>Student Name : {{ $body }}</p>

<p>Subject : {{$subject}}</p>

<p>Date : {{$date}}</p>

<p>Time : {{$time}}</p>

<p>Message : {{$msg}}</p>

<br>
Please Login to portal to accept/reject the appointment.
<br>

Thankyou! 

<br>

Student Counseling
