Hi <strong>{{ $name }}</strong>,

<p>Your Appointment time has been updated.</p>

<p>Teacher Name : {{ $body }}</p>

<p>Subject : {{$subject}}</p>

<p>New Date : {{$date}}</p>

<p>New Time : {{$time}}</p>

<p>Message : {{$tchMessage}}</p>
<br>
Thankyou!

<br>

Student Counseling
