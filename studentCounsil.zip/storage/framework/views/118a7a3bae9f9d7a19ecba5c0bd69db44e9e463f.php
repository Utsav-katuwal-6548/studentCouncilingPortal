<?php echo $__env->make('includes.student.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="text-center">
    <h4>Select Teacher For Appointment</h4>  
   
</div>
<h5><a href="/student/allCourses">Courses</a> / <?php echo e($courseId); ?> /Select Teacher</h5>


<br>
<div class="row">
    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <i class="fa fa-user"></i>
                <strong class="card-title pl-2"><?php echo e($t->full_name); ?></strong>
            </div>
            <div class="card-body">
                <div class="mx-auto d-block">
                   
                <h5 class="text-sm-center mt-2 mb-1"><?php echo e($t->full_name); ?></h5>
                    <div class="location text-sm-center">
                        <i class="fa fa-mail"></i> <?php echo e($t->email); ?></div>
                </div>
                <hr>
                <div class="card-text text-sm-center">
                <a type="button" class="btn btn-primary" href="/selectTime/<?php echo e($courseId); ?>/<?php echo e($t->user_id); ?>">
                        <i class="fa fa-clock-o"></i>&nbsp; Proceed</a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>



<?php echo $__env->make('includes.student.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
                        
                     
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/student/courseTeacher.blade.php ENDPATH**/ ?>