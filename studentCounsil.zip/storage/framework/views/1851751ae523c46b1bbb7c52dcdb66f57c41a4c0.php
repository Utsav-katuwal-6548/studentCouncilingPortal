<?php echo $__env->make('includes.teacher.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
<h3 class="title-5 m-b-35"> Change Available Time</h3>
<div class="row">

   
    <div class="table-responsive table-responsive-data2">
        <form action="/teacher/updateTime" method="post">
            <?php echo csrf_field(); ?>
            <h5>Current Time : </h5>
        <input type="text" name="time" value="<?php echo e($time1); ?>" class="form-control"> <br>
        <input type="submit" class="btn btn-warning mt-4" value="Update Time">
        </form>
      
    </div>

</div>



<?php echo $__env->make('includes.teacher.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      



<script>

    $(document).ready(function() {
        $('#example').DataTable( {
            "order": [[ 3, "desc" ]]
        } );
       
    } );
    
    </script>




<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views//teacher/changeTime.blade.php ENDPATH**/ ?>