<?php echo $__env->make('includes.student.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
<h3 class="title-5 m-b-35"> My Appointment Details</h3>
<div class="row">

   
    <div class="table-responsive table-responsive-data2">
        <table id="example" class="display table table-borderless table-striped table-earning" style="width:100%">
            <thead>
                <tr>
                    <th>Teacher</th>
                    <th>Course</th>
              
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Action</th>
                  
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($a->teacher->full_name); ?></td>
                <td><?php echo e($a->course_id); ?></td>
          
                <td><?php echo e($a->date); ?></td>
                <td><?php echo e($a->time); ?></td>
                <?php if($a->status == 0): ?>
                    <td><span class="badge badge-info">Waiting For Approval</span></td>
                <?php elseif($a->status == 1): ?>
                        <td> <span class="badge badge-success">Approved</span></td>
                <?php elseif($a->status == 2): ?>
                        <td> <span class="badge badge-danger">Rejected</span></td>
                        <?php elseif($a->status == 3): ?>
                        <td> <span class="badge badge-primary">Completed</span></td>
                        <?php elseif($a->status == 4): ?>
                        <td> <span class="badge badge-secondary">Cancled</span></td>
                <?php endif; ?>

              
                    <td>
                            <?php if($a->status == 0 ||  $a->status == 1 ): ?>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-decline-<?php echo e($a->appointment_id); ?>">
                                <i class="fa fa-times"></i>&nbsp; Cancel Appointment</button>
                                <?php endif; ?>   
                    </td>
            
                
                
        
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

</div>



<?php echo $__env->make('includes.student.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      



<script>

    $(document).ready(function() {
        $('#example').DataTable( {
            "order": [[ 3, "desc" ]]
        } );
       
    } );
    
    </script>

    
<?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-decline-<?php echo e($b->appointment_id); ?>" tabindex="-1" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

            <h5 class="modal-title">Cancel Appointment </h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">Course</div>
                    <div class="col-md-8">  <?php echo e($b->course_id); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Student</div>
                    <div class="col-md-8"> <?php echo e($b->teacher->user_id); ?> / <?php echo e($b->teacher->full_name); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Date/ Time</div>
                    <div class="col-md-8"> <?php echo e($b->date); ?> / <?php echo e($b->time); ?> </div>
                </div>
                <div class="row">
                    <div class="col-md-4">Message</div>
                    <div class="col-md-8"><?php echo e($b->message); ?>  </div>
                </div>

                <form action="/student/cancel/<?php echo e($b->appointment_id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        Message : 
                        <textarea name="student_reject_message" class="form-control" autofocus></textarea>
                        <button type="submit" class="btn btn-danger mt-3">Cancel Appointment</button>
                   </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/student/appointment.blade.php ENDPATH**/ ?>