<?php echo $__env->make('includes.teacher.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
<h3 class="title-5 m-b-35"> Pending Appointments </h3>
<div class="row">

   
    <div class="table-responsive table-responsive-data2">
        <table id="example" class="display table table-borderless table-striped table-earning" style="width:100%">
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Course</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Action</th>
                  
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($a->student->full_name); ?></td>
                <td><?php echo e($a->course_id); ?></td>
                <td><?php echo e($a->date); ?></td>
                <td><?php echo e($a->time); ?></td>
                <td>
                    <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#modal-centered-<?php echo e($a->appointment_id); ?>">
                        <i class="fa fa-eye"></i>&nbsp; View</button>
                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal-accept-<?php echo e($a->appointment_id); ?>">
                        <i class="fa fa-check"></i>&nbsp; Accept</button>
                        <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-decline-<?php echo e($a->appointment_id); ?>">
                            <i class="fa fa-times"></i>&nbsp; Decline</button>   
                </td>
        
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

</div>



<?php echo $__env->make('includes.teacher.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      



<script>

    $(document).ready(function() {
        $('#example').DataTable( {
            "order": [[ 3, "desc" ]]
        } );
       
    } );
    
</script>

<?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-centered-<?php echo e($b->appointment_id); ?>" tabindex="-1" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

            <h5 class="modal-title">View Appointment Details</h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">Course</div>
                    <div class="col-md-8">  <?php echo e($b->course_id); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Student</div>
                    <div class="col-md-8"> <?php echo e($b->student->user_id); ?> / <?php echo e($b->student->full_name); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Date/ Time</div>
                    <div class="col-md-8"> <?php echo e($b->date); ?> / <?php echo e($b->time); ?> </div>
                </div>
                <div class="row">
                    <div class="col-md-4">Message</div>
                    <div class="col-md-8"><?php echo e($b->message); ?>  </div>
                </div>

                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-accept-<?php echo e($b->appointment_id); ?>" tabindex="-1" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

            <h5 class="modal-title">Accept Appointment </h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">Course</div>
                    <div class="col-md-8">  <?php echo e($b->course_id); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Student</div>
                    <div class="col-md-8"> <?php echo e($b->student->user_id); ?> / <?php echo e($b->student->full_name); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Date/ Time</div>
                    <div class="col-md-8"> <?php echo e($b->date); ?> / <?php echo e($b->time); ?> </div>
                </div>
                <div class="row">
                    <div class="col-md-4">Message</div>
                    <div class="col-md-8"><?php echo e($b->message); ?>  </div>
                </div>

                <form action="/teacher/accept/<?php echo e($b->appointment_id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        Teacher Message : 
                        <textarea name="teacher_message" class="form-control" autofocus></textarea>
                        <button type="submit" class="btn btn-success mt-3">Accept Appointment</button>
                   </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-decline-<?php echo e($b->appointment_id); ?>" tabindex="-1" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">

            <h5 class="modal-title">Decline Appointment </h5>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4">Course</div>
                    <div class="col-md-8">  <?php echo e($b->course_id); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Student</div>
                    <div class="col-md-8"> <?php echo e($b->student->user_id); ?> / <?php echo e($b->student->full_name); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-4">Date/ Time</div>
                    <div class="col-md-8"> <?php echo e($b->date); ?> / <?php echo e($b->time); ?> </div>
                </div>
                <div class="row">
                    <div class="col-md-4">Message</div>
                    <div class="col-md-8"><?php echo e($b->message); ?>  </div>
                </div>

                <form action="/teacher/decline/<?php echo e($b->appointment_id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        Teacher Message : 
                        <textarea name="teacher_message" class="form-control" autofocus></textarea>
                        <button type="submit" class="btn btn-danger mt-3">Decline Appointment</button>
                   </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views//teacher/pendingApp.blade.php ENDPATH**/ ?>