<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   



<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      
                        
                     
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/welcome.blade.php ENDPATH**/ ?>