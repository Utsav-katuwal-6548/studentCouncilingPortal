<li <?php if($title == 'Dashboard'): ?> class="active" <?php endif; ?>>
    <a href="/teacher/dashboard"  >
        <i class="fas fa-home"></i>Dashboard</a>
</li>



<li  <?php if($title == 'My Appointment'  || $title == "Pending Appointment"): ?> class="active has-sub"  <?php else: ?> class="has-sub" <?php endif; ?>>
    <a class="js-arrow" href="#">
    <i class="fas fa-calendar-check-o"></i>Appointments</a>
    <ul class="list-unstyled navbar__sub-list js-sub-list" <?php if($title == 'My Appointment' || $title == "Pending Appointment" ): ?> style="display:block" <?php else: ?> style="display:none"  <?php endif; ?> >
    <li <?php if($title == 'Pending Appointment' ): ?> class="active" <?php endif; ?> >
    <a href="/teacher/pendingAppointment">Pending Appointments</a>
    </li>

    <li <?php if($title == 'My Appointment' ): ?> class="active" <?php endif; ?>>
        <a href="/teacher/myAppointment" >All Appointments</a>
    </li>
    </ul>
    </li>

    <li <?php if($title == 'Change Available Time'): ?> class="active" <?php endif; ?>>
        <a href="/teacher/changeTime"  >
            <i class="fas fa-clock"></i>Change Available Time</a>
    </li>
    
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/includes/teacher/navItem.blade.php ENDPATH**/ ?>