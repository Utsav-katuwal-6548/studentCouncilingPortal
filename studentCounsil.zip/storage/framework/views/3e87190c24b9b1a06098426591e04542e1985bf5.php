Hi <strong><?php echo e($name); ?></strong>,

<p>Your Appointment time has been updated.</p>

<p>Teacher Name : <?php echo e($body); ?></p>

<p>Subject : <?php echo e($subject); ?></p>

<p>New Date : <?php echo e($date); ?></p>

<p>New Time : <?php echo e($time); ?></p>

<p>Message : <?php echo e($tchMessage); ?></p>
<br>
Thankyou!

<br>

Student Counseling
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/emails/timeChange.blade.php ENDPATH**/ ?>