Hi <strong><?php echo e($name); ?></strong>,

<p>Your Appointment request has been approved.</p>

<p>Teacher Name : <?php echo e($body); ?></p>

<p>Subject : <?php echo e($subject); ?></p>

<p>Date : <?php echo e($date); ?></p>

<p>Time : <?php echo e($time); ?></p>

<br>
Thankyou!

<br>

Student Counseling
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/emails/studentAccept.blade.php ENDPATH**/ ?>