Hi <strong><?php echo e($name); ?></strong>,

<p>You have new appointment Request</p>

<p>Student Name : <?php echo e($body); ?></p>

<p>Subject : <?php echo e($subject); ?></p>

<p>Date : <?php echo e($date); ?></p>

<p>Time : <?php echo e($time); ?></p>

<p>Message : <?php echo e($msg); ?></p>

<br>
Please Login to portal to accept/reject the appointment.
<br>

Thankyou! 

<br>

Student Counseling
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/emails/teacher.blade.php ENDPATH**/ ?>