
<li>
    <a href="/admin/getAllUsers" >
        <i class="fas fa-user"></i>Users</a>
</li>

<li>
    <a href="/admin/getAllCourses" >
        <i class="fas fa-book"></i>Courses</a>
</li>

<li>
    <a href="/admin/getAllSections" >
        <i class="fas fa-link"></i>Sections</a>
</li>

<li>
    <a href="/admin/getAllEnrollments" >
        <i class="fas  fa-graduation-cap"></i>Enrollment</a>
</li><?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/includes/navItem.blade.php ENDPATH**/ ?>