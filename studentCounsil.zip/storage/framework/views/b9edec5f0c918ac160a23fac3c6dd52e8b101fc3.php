<?php echo $__env->make('includes.student.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   
<div class="row">

    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-4">
        <div class="card border border-success">
        <div class="card-header">
        <strong class="card-title"><?php echo e($c->short_name); ?></strong>
        </div>
        <div class="card-body">
        <p class="card-text">
            <p class="mb-4"> Course : <?php echo e($c->long_name); ?></p>
        <a type="button" class="btn btn-primary" href="/getTeacherFromCourse/<?php echo e($c->course_id); ?>">
            <i class="fa fa-clock-o"></i>&nbsp; Book Appointment</a>
          
        </p>
        </div>
        </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php echo $__env->make('includes.student.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>      


                        
                    
<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
    <div class="modal-header">
    <h5 class="modal-title" id="mediumModalLabel">Select Teacher</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <div class="modal-body">
    <p>
    There are three species of zebras: the plains zebra, the mountain zebra and the Grévy's zebra. The plains zebra and the mountain
    zebra belong to the subgenus Hippotigris, but Grévy's zebra is the sole species of subgenus Dolichohippus. The latter
    resembles an ass, to which it is closely related, while the former two are more horse-like. All three belong to the
    genus Equus, along with other living equids.
    </p>
    </div>
    <div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
    <button type="button" class="btn btn-primary">Confirm</button>
    </div>
    </div>
    </div>
    </div>

<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views//student/courses.blade.php ENDPATH**/ ?>