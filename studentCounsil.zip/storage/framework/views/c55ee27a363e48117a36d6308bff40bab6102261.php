Hi <strong><?php echo e($name); ?></strong>,

<p>Your Appointment request has been sent to the selected Teacher.</p>

<p>Teacher Name : <?php echo e($body); ?></p>

<p>Subject : <?php echo e($subject); ?></p>

<p>Date : <?php echo e($date); ?></p>

<p>Time : <?php echo e($time); ?></p>

Thankyou!

Student Counseling
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/emails/student.blade.php ENDPATH**/ ?>