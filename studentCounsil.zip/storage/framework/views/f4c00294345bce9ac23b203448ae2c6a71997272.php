<style>
    .copyright {
      position: fixed;
      left: 0;
      bottom: 0;
      width: 100%;
    
      color: white;
      text-align: center;
    }
    </style>

<div class="row">
    <div class="col-md-12">
        
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="<?php echo e(asset('vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/slick/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/counter-up/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js" 
integrity="sha512-8QFTrG0oeOiyWo/VM9Y8kgxdlCryqhIxVeRpWSezdRRAvarxVtwLnGroJgnVW9/XBRduxO/z1GblzPrMQoeuew==" 
crossorigin="anonymous"></script>
</html>







<?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/includes/footer.blade.php ENDPATH**/ ?>