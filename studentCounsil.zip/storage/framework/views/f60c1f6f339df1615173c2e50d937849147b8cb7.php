<li <?php if($title == 'Dashboard'): ?> class="active" <?php endif; ?>>
    <a href="/student/dashboard"  >
        <i class="fas fa-home"></i>Dashboard</a>
</li>


<li <?php if($title == 'All Courses' || $title == 'Select Teacher' || $title =='Select Time'): ?> class="active" <?php endif; ?>>
    <a href="/student/allCourses"  >
        <i class="fas fa-book"></i>Courses</a>
</li>

<li <?php if($title == 'My Appointment' ): ?> class="active" <?php endif; ?>>
    <a href="/student/myAppointment" >
        <i class="fas  fa-calendar-check-o"></i>My Appointment</a>
</li>
<?php /**PATH C:\xampp\htdocs\studentCounsil\resources\views/includes/student/navItem.blade.php ENDPATH**/ ?>